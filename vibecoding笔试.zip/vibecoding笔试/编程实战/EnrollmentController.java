package com.school.enrollment.controller;

import com.school.enrollment.entity.EnrollRecord;
import com.school.enrollment.service.EnrollmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/* * [AI 自动生成]: Controller 层面的所有代码，包括路由映射、参数接收等，非常标准化。
 */
@RestController
@RequestMapping("/api/enrollment")
public class EnrollmentController {

    @Autowired
    private EnrollmentService enrollmentService;

    @PostMapping("/import")
    public List<EnrollRecord> importData(@RequestBody Map<String, String> payload) {
        String csvData = payload.get("csvData");
        return enrollmentService.importCsvData(csvData);
    }

    @GetMapping("/search")
    public List<EnrollRecord> searchData(
            @RequestParam(required = false) String studentId,
            @RequestParam(required = false) String courseId,
            @RequestParam(required = false) String courseName,
            @RequestParam(required = false) String courseType) {
        return enrollmentService.search(studentId, courseId, courseName, courseType);
    }
}