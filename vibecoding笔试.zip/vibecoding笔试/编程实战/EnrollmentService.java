package com.school.enrollment.service;

import com.school.enrollment.entity.EnrollRecord;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

/* [AI 自动生成]: 基础的 @Service 注解和类的基本结构 */
@Service
public class EnrollmentService {

    /*
     * ==========================================
     * [人工修改优化]: 使用 CopyOnWriteArrayList 代替 ArrayList
     * 修改原因：Web 应用是多线程环境。如果使用普通的 ArrayList，
     * 当一个用户在检索，另一个用户在批量导入时，极易触发 ConcurrentModificationException（并发修改异常）。
     * 换成线程安全集合，适配真实并发场景。
     * ==========================================
     */
    private final List<EnrollRecord> database = new CopyOnWriteArrayList<>();

    public EnrollmentService() {
        // [AI 自动生成]: 预写几条死数据用于演示
        database.add(new EnrollRecord("S000002", "C000003", "计算机网络", "公共课"));
        database.add(new EnrollRecord("S000001", "C000001", "Java程序设计", "专业课"));
    }

    /* [AI 自动生成]: 导入方法的主体框架 */
    public List<EnrollRecord> importCsvData(String csvData) {
        if (csvData == null || csvData.trim().isEmpty()) {
            return database;
        }

        // [AI 自动生成]: 基础的换行符切分
        List<EnrollRecord> newRecords = Arrays.stream(csvData.split("\n"))
                .map(String::trim)
                /*
                 * ==========================================
                 * [人工修改优化]: 增强脏数据容错能力
                 * 修改原因：真实业务中，用户输入的 CSV 可能包含空行，或者少写了逗号。
                 * 如果直接 parts[3]，会导致 ArrayIndexOutOfBoundsException，导致整个 500 条批处理崩溃。
                 * 增加长度校验，过滤无效数据。
                 * ==========================================
                 */
                .filter(line -> !line.isEmpty())
                .map(line -> {
                    String[] parts = line.split(",");
                    if (parts.length >= 4) { // 人工加入的安全校验
                        return new EnrollRecord(parts[0].trim(), parts[1].trim(), parts[2].trim(), parts[3].trim());
                    }
                    return null;
                })
                .filter(Objects::nonNull) // 剔除解析失败的 null 值
                .collect(Collectors.toList());

        // [AI 自动生成]: 合并数据
        database.addAll(newRecords);

        // [AI 自动生成]: 基于实体类 equals 的 distinct 去重，以及多字段排序
        List<EnrollRecord> processedList = database.stream()
                .distinct()
                .sorted(Comparator.comparing(EnrollRecord::getStudentId)
                        .thenComparing(EnrollRecord::getCourseId))
                .collect(Collectors.toList());

        // [AI 自动生成]: 更新内存数据库
        database.clear();
        database.addAll(processedList);

        return database;
    }

    /* [AI 自动生成]: 简单的多条件动态拼接查询 (Stream API filter 实现) */
    public List<EnrollRecord> search(String studentId, String courseId, String courseName, String courseType) {
        return database.stream()
                .filter(record -> (studentId == null || studentId.isEmpty() || record.getStudentId().contains(studentId)))
                .filter(record -> (courseId == null || courseId.isEmpty() || record.getCourseId().contains(courseId)))
                .filter(record -> (courseName == null || courseName.isEmpty() || record.getCourseName().contains(courseName)))
                .filter(record -> (courseType == null || courseType.isEmpty() || record.getCourseType().equals(courseType)))
                .collect(Collectors.toList());
    }
}