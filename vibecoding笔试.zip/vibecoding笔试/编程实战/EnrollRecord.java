package com.school.enrollment.entity;

import java.util.Objects;

/* * [AI 自动生成]: 基础类定义、字段声明以及基础的 Getters 和 Setters
 */
public class EnrollRecord {
    private String studentId;
    private String courseId;
    private String courseName;
    private String courseType;

    public EnrollRecord(String studentId, String courseId, String courseName, String courseType) {
        this.studentId = studentId;
        this.courseId = courseId;
        this.courseName = courseName;
        this.courseType = courseType;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getCourseType() {
        return courseType;
    }

    public void setCourseType(String courseType) {
        this.courseType = courseType;
    }

    /*
     * ==========================================
     * [人工修改优化]: 重写 equals 和 hashCode
     * 修改原因：AI 默认可能不会重写，或者会将 4 个字段都纳入计算。
     * 但题目明确要求“去重规则：学生 ID + 课程 ID 完全一致视为重复记录，与课程名称无关”。
     * 因此，必须人工干预，强制只用 studentId 和 courseId 进行哈希和等价计算，
     * 这样后续 Service 层的 Stream.distinct() 才能按正确的业务逻辑去重。
     * ==========================================
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EnrollRecord that = (EnrollRecord) o;
        return Objects.equals(studentId, that.studentId) &&
                Objects.equals(courseId, that.courseId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(studentId, courseId);
    }
}