package vibecoding笔试;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 选课记录实体类 (题目已给出)
 */
class EnrollRecord {
    private String studentId;
    private String courseId;
    private String courseName;

    public EnrollRecord(String studentId, String courseId, String courseName) {
        this.studentId = studentId;
        this.courseId = courseId;
        this.courseName = courseName;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    @Override
    public String toString() {
        return String.format("学生ID：%s，课程ID：%s，课程名称：%s", studentId, courseId, courseName);
    }
}

/**
 * 学生选课基础处理工具
 */
class EnrollmentProcessor {

    /**
     * 处理选课记录：去重、排序、打印并返回
     *
     * @param records 原始选课记录列表
     * @return 处理后的选课记录列表
     */
    public static List<EnrollRecord> processRecords(List<EnrollRecord> records) {
        if (records == null || records.isEmpty()) {
            return new ArrayList<>();
        }

        /* * 核心处理逻辑：
         * 1. 排序规则：先按 studentId 升序，再按 courseId 升序。
         * 2. 去重规则：当 studentId 和 courseId 完全一致时，Comparator 会返回 0。
         * TreeSet 发现比较结果为 0 时，会认为它们是重复元素，从而自动保留第一个，丢弃后续的重复项。
         */
        List<EnrollRecord> processedList = records.stream()
                .collect(Collectors.collectingAndThen(
                        Collectors.toCollection(() -> new TreeSet<>(
                                Comparator.comparing(EnrollRecord::getStudentId)
                                        .thenComparing(EnrollRecord::getCourseId)
                        )),
                        ArrayList::new // 将 TreeSet 转换回 ArrayList 返回
                ));

        // 输出要求：逐行打印格式化信息 (利用了实体类重写的 toString)
        processedList.forEach(System.out::println);

        // 返回处理后的列表
        return processedList;
    }

    // --- 测试用例 ---
    public static void main(String[] args) {
        // 模拟接收到的学生选课信息列表
        List<EnrollRecord> rawRecords = Arrays.asList(
                new EnrollRecord("S000002", "C000003", "计算机网络"),
                new EnrollRecord("S000001", "C000001", "Java程序设计"),
                new EnrollRecord("S000001", "C000002", "数据结构"),
                new EnrollRecord("S000001", "C000001", "Java程序设计(脏数据，应被去重)"), // 重复项
                new EnrollRecord("S000003", "C000001", "Java程序设计"),
                new EnrollRecord("S000002", "C000001", "高等数学")
        );

        System.out.println("============== 原始数据条数: " + rawRecords.size() + " ==============");

        System.out.println("\n============== 开始处理并输出 ==============");
        List<EnrollRecord> resultList = processRecords(rawRecords);

        System.out.println("\n============== 处理后数据条数: " + resultList.size() + " ==============");
    }
}